import pathlib
import numpy as np
import solver

DATA_DIR = pathlib.Path(".")
A1 = DATA_DIR / "附件1.xlsx"
OUT = pathlib.Path("results")
OUT.mkdir(exist_ok=True)


def main():
    t_a, Ta, Ca = solver.read1(A1)
    ambient = solver.Environmental_interpolation(t_a, Ta, Ca)

    # 步长1s/0.1cm
    times = np.arange(0.0, 1800.0 + 0.5, 1.0)
    t, r, T_old, C_old = solver.simulateQ1(1800.0, ambient, config=solver.CONFIG, dt=1.0, output_t=times)

    positions = r * 100.0
    target = np.arange(0.0, 2.0 + 1e-9, 0.1)
    index = [int(np.argmin(abs(positions - x))) for x in target]

    solver.result12(OUT / "result1.xlsx", t, target, T_old[:, index], C_old[:, index])
    np.savez(OUT / "Q1 data.npz", time=t, r=r, T=T_old, C=C_old)
    print("Q1计算结果已存至：", OUT / "result1.xlsx")
    print(f"T范围: [{T_old.min():.4f}, {T_old.max():.4f}]°C")
    print(f"C范围: [{C_old.min():.6f}, {C_old.max():.6f}]")


if __name__ == "__main__":
    main()
