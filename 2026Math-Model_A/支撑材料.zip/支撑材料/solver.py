"""统一数值求解器"""

from __future__ import annotations

import dataclasses
import pathlib
import numpy as np
import scipy.interpolate


@dataclasses.dataclass
class Config:
    r0: float = 2.0
    long: float = 25.0
    T0: float = 28.0
    C0: float = 2.55
    h: float = 25.0
    hm: float = 8.0e-7
    Nr: int = 41
    Nxi: int = 41
    picard_tolal_T: float = 1e-7
    picard_tolal_C: float = 1e-8
    picard_maxiteration: int = 20
    dt_fixed: float = 60.0
    data: str = "."
    output: str = "results"


CONFIG = Config()


def read1(path):
    import pandas as pd
    df = pd.read_excel(path)
    t = df['时间'].to_numpy(dtype=float)
    Ta = df['温度'].to_numpy(dtype=float)
    Ca = df['水分浓度'].to_numpy(dtype=float)
    index = np.argsort(t)
    return t[index], Ta[index], Ca[index]


def read2(path):
    import pandas as pd
    df = pd.read_excel(path)
    t = df['时间'].to_numpy(dtype=float)
    R = df['半径'].to_numpy(dtype=float)
    index = np.argsort(t)
    return t[index], R[index]


class Environmental_interpolation:

    def __init__(self, t, Ta, Ca):
        self.t = np.asarray(t, float)
        self.Ta = np.asarray(Ta, float)
        self.Ca = np.asarray(Ca, float)
        self._Ta = (scipy.interpolate.PchipInterpolator(self.t, self.Ta, extrapolate=False) if len(self.t) >= 3 else None)
        self._Ca = (scipy.interpolate.PchipInterpolator(self.t, self.Ca, extrapolate=False) if len(self.t) >= 3 else None)

    def __call__(self, t):
        scalar = np.isscalar(t)
        ttonum_arry = np.atleast_1d(np.asarray(t, float))
        ttomax = np.clip(ttonum_arry, self.t[0], self.t[-1])
        if self._Ta is not None:
            Ta = np.asarray(self._Ta(ttomax), float)
            Ca = np.asarray(self._Ca(ttomax), float)
        else:
            Ta = np.interp(ttomax, self.t, self.Ta)
            Ca = np.interp(ttomax, self.t, self.Ca)
        Ta[ttonum_arry < self.t[0]] = self.Ta[0]
        Ca[ttonum_arry < self.t[0]] = self.Ca[0]
        return (float(Ta[0]), float(Ca[0])) if scalar else (Ta, Ca)


class Radius_interpolation:

    def __init__(self, t, r):
        self.t = np.asarray(t, float)
        self.r = np.asarray(r, float)
        self._R = (scipy.interpolate.PchipInterpolator(self.t, self.r, extrapolate=False) if len(self.t) >= 3 else None)

    def R(self, t):
        ttonum_arry = np.asarray(t, float)
        ttomax = np.clip(ttonum_arry, self.t[0], self.t[-1])
        return np.asarray(self._R(ttomax) if self._R is not None else np.interp(ttomax, self.t, self.r))

    def Rdot(self, t, window=1800.0):
        ttonum_arry = float(t)
        a = max(self.t[0], ttonum_arry - window)
        b = min(self.t[-1], ttonum_arry + window)
        if b <= a:
            return 0.0
        return float((self.R(b) - self.R(a)) / (b - a))


# 附录参数
def para_q1(C):
    C = np.maximum(np.asarray(C, float), 1e-12)
    ρ = np.full_like(C, 820.0)
    cp = np.full_like(C, 2600.0)
    k = np.full_like(C, 0.36)
    D = 7e-9 * np.exp(-0.89 / C)
    return ρ, cp, k, D


def para_q23(C, T_c):
    C = np.maximum(np.asarray(C, float), 1e-12)
    T_k = np.asarray(T_c, float) + 273.15
    ρ = 650 + 128 * C
    cp = 1450 + 2736 * C / (C + 1)
    k = 0.21 + 0.38 * C / (C + 1)
    D = 2.4e-3 * np.exp(-0.45 / C) * np.exp(-3850 / T_k)
    return ρ, cp, k, D


def para_q4(C, T_c):
    C = np.maximum(np.asarray(C, float), 1e-12)
    T_k = np.asarray(T_c, float) + 273.15
    ρ = 760 + 90 * C
    cp = 1850 + 2150 * C / (C + 1)
    k = 0.12 + 0.20 * C / (C + 1)
    D = 4.2e-4 * np.exp(-0.30 / C) * np.exp(-3850 / T_k)
    return ρ, cp, k, D


# 线性求解
def TDMA(Subd, dia, Superd, rhs):
    Subd = np.asarray(Subd, float).copy()
    dia = np.asarray(dia, float).copy()
    Superd = np.asarray(Superd, float).copy()
    rhs = np.asarray(rhs, float).copy()
    n = len(dia)
    if n == 1:
        return rhs / dia
    for i in range(1, n):
        m = Subd[i - 1] / dia[i - 1]
        rhs[i] -= m * rhs[i - 1]
        dia[i] -= m * Superd[i - 1]
    x = np.empty(n)
    x[-1] = rhs[-1] / dia[-1]
    for i in range(n - 2, -1, -1):
        x[i] = (rhs[i] - Superd[i] * x[i + 1]) / dia[i]
    return x


def face_mean(x):
    return (x[:-1] + x[1:]) * 0.5


# 基于隐式Euler格式的固定半径扩散求解

def fixed_radius(u_past, KD, Storage, R, dt, TC_a, transfer_KD):
    u_past = np.asarray(u_past, float)
    KD = np.asarray(KD, float)
    Storage = np.asarray(Storage, float)
    N = len(u_past)
    dr = R / (N - 1)
    r = np.arange(N) * dr
    fc = face_mean(KD)
    lo = np.zeros(N - 1)
    di = np.zeros(N)
    up = np.zeros(N - 1)
    rhs = Storage / dt * u_past
    lamda0 = 4 * fc[0] / dr ** 2
    di[0] = Storage[0] / dt + lamda0
    up[0] = -lamda0
    for j in range(1, N - 1):
        rp = r[j] + 0.5 * dr
        rm = r[j] - 0.5 * dr
        αp = rp * fc[j] / (r[j] * dr ** 2)
        αm = rm * fc[j - 1] / (r[j] * dr ** 2)
        lo[j - 1] = -αm
        di[j] = Storage[j] / dt + αp + αm
        up[j] = -αp
    q = 1 / (dr / (2 * KD[-1]) + 1 / transfer_KD)
    αm = (R - 0.5 * dr) * fc[-1] / (R * dr ** 2)
    sh = Storage[-1] / (2 * dt)
    di[-1] = sh + αm + q / dr
    lo[-1] = -αm
    rhs[-1] = sh * u_past[-1] + q / dr * TC_a
    return TDMA(lo, di, up, rhs)


# 固定半径主求解

def simulatefixed_radius(t_end, ambient, problem, config=CONFIG, dt=None, output_t=None):
    if dt is None:
        dt = config.dt_fixed
    R = config.r0 / 100
    n = config.Nr
    r = np.linspace(0, R, n)
    if output_t is None:
        output_t = np.arange(0, t_end + 0.5 * dt, dt)
    output_t = np.asarray(output_t, float)
    T = np.full(n, config.T0)
    C = np.full(n, config.C0)
    th = [0.0]
    TH = [T.copy()]
    CH = [C.copy()]
    t = 0.0
    oidx = 1
    while t < t_end - 1e-12:
        dtn = min(dt, t_end - t)
        tn = t + dtn
        Ta, Ca = ambient(tn)
        Ti, Ci = T.copy(), C.copy()
        for _ in range(config.picard_maxiteration):
            ρ, cp, k, D = para_q23(Ci, Ti)
            Tn = fixed_radius(T, k, ρ * cp, R, dtn, Ta, config.h)
            Cn = fixed_radius(C, D, np.ones(n), R, dtn, Ca, config.hm)
            eT = np.max(np.abs(Tn - Ti))
            eC = np.max(np.abs(Cn - Ci))
            Ti, Ci = Tn, Cn
            if eT < config.picard_tolal_T and eC < config.picard_tolal_C:
                break
        T, C = Ti, Ci
        t = tn
        while oidx < len(output_t) and output_t[oidx] <= t + 1e-10:
            th.append(t)
            TH.append(T.copy())
            CH.append(C.copy())
            oidx += 1
    return np.asarray(th), r, np.asarray(TH), np.asarray(CH)


def simulateQ1(t_end, ambient, config=CONFIG, dt=None, output_t=None):
    if dt is None:
        dt = config.dt_fixed
    R = config.r0 / 100
    N = config.Nr
    r = np.linspace(0, R, N)
    if output_t is None:
        output_t = np.arange(0, t_end + 0.5 * dt, dt)
    output_t = np.asarray(output_t, float)
    T = np.full(N, config.T0)
    C = np.full(N, config.C0)
    th = [0.0]
    TH = [T.copy()]
    CH = [C.copy()]
    t = 0.0
    oidx = 1
    while t < t_end - 1e-12:
        dtn = min(dt, t_end - t)
        tn = t + dtn
        Ta, Ca = ambient(tn)
        Ti, Ci = T.copy(), C.copy()
        for _ in range(config.picard_maxiteration):
            rho, cp, k, D = para_q1(Ci)
            Tn = fixed_radius(T, k, rho * cp, R, dtn, Ta, config.h)
            Cn = fixed_radius(C, D, np.ones(N), R, dtn, Ca, config.hm)
            eT = np.max(np.abs(Tn - Ti))
            eC = np.max(np.abs(Cn - Ci))
            Ti, Ci = Tn, Cn
            if eT < config.picard_tolal_T and eC < config.picard_tolal_C:
                break
        T, C = Ti, Ci
        t = tn
        while oidx < len(output_t) and output_t[oidx] <= t + 1e-10:
            th.append(t)
            TH.append(T.copy())
            CH.append(C.copy())
            oidx += 1
    return np.asarray(th), r, np.asarray(TH), np.asarray(CH)


# 移动边界扩散求解
def moving(u_past, KD, Storage, R_m, Rdot_m_s, dt, KD_value, transfer_KD, xi):
    u_past = np.asarray(u_past, float)
    KD = np.asarray(KD, float)
    Storage = np.asarray(Storage, float)
    N = len(u_past)
    dx = xi[1] - xi[0]
    fc = face_mean(KD)

    a = xi * Rdot_m_s / max(R_m, 1e-14)
    adv = np.zeros(N)
    adv[1:] = a[1:] * (u_past[1:] - u_past[:-1]) / dx
    rhs = Storage / dt * u_past + Storage * adv
    lo = np.zeros(N - 1)
    di = np.zeros(N)
    up = np.zeros(N - 1)
    R2 = R_m ** 2
    lamda0 = 4 * fc[0] / (R2 * dx ** 2)
    di[0] = Storage[0] / dt + lamda0
    up[0] = -lamda0

    for j in range(1, N - 1):
        xp = xi[j] + 0.5 * dx
        xm = xi[j] - 0.5 * dx
        αp = xp * fc[j] / (R2 * xi[j] * dx ** 2)
        αm = xm * fc[j - 1] / (R2 * xi[j] * dx ** 2)
        lo[j - 1] = -αm
        di[j] = Storage[j] / dt + αp + αm
        up[j] = -αp

    dr_half = R_m * dx / 2
    q = 1 / (dr_half / KD[-1] + 1 / transfer_KD)
    αm = (1 - 0.5 * dx) * fc[-1] / (R2 * dx ** 2)
    sh = Storage[-1] / (2 * dt)
    di[-1] = sh + αm + q / (R_m * dx)
    lo[-1] = -αm
    rhs[-1] = sh * u_past[-1] + Storage[-1] * adv[-1] + q / (R_m * dx) * KD_value
    return TDMA(lo, di, up, rhs)


def simulateQ4(t_end, ambient, radius_old, config=CONFIG, dt=60.0, output_t=None):
    n = config.Nxi
    xi = np.linspace(0, 1, n)
    if output_t is None:
        output_t = np.arange(0, t_end + 0.5 * dt, dt)
    output_t = np.asarray(output_t, float)
    T = np.full(n, config.T0)
    C = np.full(n, config.C0)
    th = [0.0]
    RH = [float(radius_old.R(0))]
    TH = [T.copy()]
    CH = [C.copy()]
    t = 0.0
    oidx = 1
    while t < t_end - 1e-12:
        dtn = min(dt, t_end - t)
        tn = t + dtn
        R_m = float(radius_old.R(tn)) / 100
        R_dot = radius_old.Rdot(tn) / 100
        Ta, Ca = ambient(tn)
        Ti, Ci = T.copy(), C.copy()
        for _ in range(config.picard_maxiteration):
            ρ, cp, k, D = para_q4(Ci, Ti)
            Tn = moving(T, k, ρ * cp, R_m, R_dot, dtn, Ta, config.h, xi)
            Cn = moving(C, D, np.ones(n), R_m, R_dot, dtn, Ca, config.hm, xi)
            eT = np.max(np.abs(Tn - Ti))
            eC = np.max(np.abs(Cn - Ci))
            Ti, Ci = Tn, Cn
            if eT < config.picard_tolal_T and eC < config.picard_tolal_C:
                break
        T, C = Ti, Ci
        t = tn
        while oidx < len(output_t) and output_t[oidx] <= t + 1e-10:
            th.append(t)
            RH.append(float(radius_old.R(tn)))
            TH.append(T.copy())
            CH.append(C.copy())
            oidx += 1
    return np.asarray(th), xi, np.asarray(RH), np.asarray(TH), np.asarray(CH)


def dtime(times, C_old, threshold=0.15):
    times = np.asarray(times, float)
    cmax = np.max(np.asarray(C_old, float), axis=1)
    for i in range(1, len(times)):
        if cmax[i] < threshold:
            if cmax[i] == cmax[i - 1]:
                return float(times[i])
            f = (cmax[i - 1] - threshold) / (cmax[i - 1] - cmax[i])
            return float(times[i - 1] + f * (times[i] - times[i - 1]))
    return np.nan


def weight_average(r, field):
    r = np.asarray(r, float)
    f = np.asarray(field, float)
    R = r[-1]
    return 2 * np.trapezoid(f * r, r) / (R * R)


def weight_average_xi(xi, field):
    xi = np.asarray(xi, float)
    f = np.asarray(field, float)
    return 2 * np.trapezoid(f * xi, xi)


def into_position(r_src, field, target):
    return np.interp(target, r_src, field)


# Excel输出

def build_df(times, positions, value, timeUnit="s"):
    import pandas as pd
    data = np.column_stack([times, value])
    cols = [f"时间/{timeUnit}"] + [f"{x:.4f}/cm" for x in positions]
    return pd.DataFrame(data, columns=cols)


# result1/result2
def result12(path, times, positions, T_values, C_values):
    import pandas as pd
    pathlib.Path(path).parent.mkdir(parents=True, exist_ok=True)
    cols = ["时间\\到药材中心的距离"] + [round(float(x), 4) for x in positions]
    T_v = np.round(np.asarray(T_values, float), 4)
    C_v = np.round(np.asarray(C_values, float), 4)
    df_T = pd.DataFrame(np.column_stack([times, T_v]), columns=cols)
    df_C = pd.DataFrame(np.column_stack([times, C_v]), columns=cols)
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        df_T.to_excel(writer, sheet_name="温度", index=False)
        df_C.to_excel(writer, sheet_name="水分浓度", index=False)
        # 数据区域格式化为4位小数
        for sheet_name in ["温度", "水分浓度"]:
            ws = writer.sheets[sheet_name]
            for row in ws.iter_rows(min_row=2, max_row=ws.max_row, min_col=2, max_col=ws.max_column):
                for cell in row:
                    cell.number_format = "0.0000"


# result3/result4
def result34(path, times, positions, values, position_labels=None):
    import pandas as pd
    pathlib.Path(path).parent.mkdir(parents=True, exist_ok=True)
    if position_labels is None:
        position_labels = [round(float(x), 4) for x in positions]
    cols = ["时间\\到药材中心的距离"] + list(position_labels)
    vals = np.round(np.asarray(values, float), 4)
    df = pd.DataFrame(np.column_stack([times, vals]), columns=cols)
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        df.to_excel(writer, sheet_name="水分浓度", index=False)
        ws = writer.sheets["水分浓度"]
        for row in ws.iter_rows(min_row=2, max_row=ws.max_row, min_col=2, max_col=ws.max_column):
            for cell in row:
                cell.number_format = "0.0000"
