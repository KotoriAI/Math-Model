import pathlib
import numpy as np
import solver

A1 = pathlib.Path("附件1.xlsx")
OUT = pathlib.Path("results")
OUT.mkdir(exist_ok=True)


def main():
    ta, Ta, Ca = solver.read1(A1)
    ambient = solver.Environmental_interpolation(ta, Ta, Ca)

    t_end = 72.0 * 3600.0
    outputT = np.arange(0.0, t_end + 60.0, 60.0)

    t, r, T_old, C_old = solver.simulatefixed_radius(t_end, ambient, problem=3, config=solver.CONFIG, dt=60.0,
        output_t=outputT)

    td = solver.dtime(t, C_old, threshold=0.15)
    print(f"Q3烘干时间: {td:.2f}秒 = {td / 3600:.4f}小时")

    position = r * 100.0
    target = np.arange(0.0, 2.0 + 1e-9, 0.1)
    index = [int(np.argmin(abs(position - x))) for x in target]

    # 只保存到烘干结束时刻
    if np.isfinite(td):
        mask = t <= td + 1e-6
    else:
        mask = np.ones(len(t), dtype=bool)

    solver.result34(OUT / "result3.xlsx", t[mask], target, C_old[mask][:, index])

    averageC = np.array([solver.weight_average(r, c) for c in C_old])
    np.savetxt(OUT / "Q3 drytime.txt", np.array([td, td / 3600]), header="drytime(s) drytime(h)")
    np.savez(OUT / "Q3 data.npz", time=t, r=r, T=T_old, C=C_old, avgC=averageC)
    print("Q3结果已存至：", OUT / "result3.xlsx")


if __name__ == "__main__":
    main()
