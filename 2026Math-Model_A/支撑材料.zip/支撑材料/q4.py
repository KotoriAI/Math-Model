import pathlib
import numpy as np
import solver

A1 = pathlib.Path("附件1.xlsx")
A2 = pathlib.Path("附件2.xlsx")
OUT = pathlib.Path("results")
OUT.mkdir(exist_ok=True)


def main():
    ta, Ta, Ca = solver.read1(A1)
    ambient = solver.Environmental_interpolation(ta, Ta, Ca)

    tr, R = solver.read2(A2)
    radius_old = solver.Radius_interpolation(tr, R)

    t_end = 72.0 * 3600.0
    outputT = np.arange(0.0, t_end + 60.0, 60.0)

    t, xi, R_old, T_old, C_old = solver.simulateQ4(t_end, ambient, radius_old, config=solver.CONFIG, dt=60.0,
        output_t=outputT)

    td = solver.dtime(t, C_old, threshold=0.15)
    print(f"Q4 烘干时间: {td:.2f} s = {td / 3600:.4f} h")

    # 0~1.9 cm和药材表面
    target = np.arange(0.0, 1.9 + 1e-9, 0.1)
    position_labels = [round(float(x), 1) for x in target] + ["药材表面"]

    nout = len(t)
    nposition = len(target)
    C_out = np.zeros((nout, nposition + 1))

    for i in range(nout):
        R = R_old[i]
        # 物理位置
        r_phy = xi * R
        C_row = C_old[i]

        for j, rc in enumerate(target):
            if rc <= R + 1e-9:
                C_out[i, j] = np.interp(rc, r_phy, C_row)
            else:
                C_out[i, j] = C_row[-1]
        C_out[i, -1] = C_row[-1]

    if np.isfinite(td):
        Mask = t <= td + 1e-6
    else:
        Mask = np.ones(len(t), dtype=bool)

    solver.result34(OUT / "result4.xlsx", t[Mask], target, C_out[Mask], position_labels=position_labels)

    averageC = np.array([solver.weight_average_xi(xi, c) for c in C_old])
    np.savetxt(OUT / "Q4 radius and drying.txt", np.column_stack([t, R_old, np.max(C_old, axis=1)]),
               header="time(s) radius(cm) Cmax")
    np.savetxt(OUT / "Q4 drytime.txt", np.array([td, td / 3600]), header="drytime(s) drytime(h)")
    np.savez(OUT / "Q4 data.npz", time=t, xi=xi, R_cm=R_old, T=T_old, C=C_old, avgC=averageC)
    print("Q4结果已存至", OUT / "result4.xlsx")


if __name__ == "__main__":
    main()
